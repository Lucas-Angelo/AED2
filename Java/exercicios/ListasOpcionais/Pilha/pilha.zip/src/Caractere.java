public class Caractere{
	
	private char letra;
	
	Caractere() {
		letra = ' ';
	}
	
	Caractere(char l) {
		letra = l;
	}
	
	public char getLetra() {
		return letra;
	} 
	
	public void setLetra(char l) {
		letra = l;
	}
}